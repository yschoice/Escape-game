-----------------------------------------------------------------------------------------
--
-- Pipe.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view
	local score = {}
	score[1]=0
	score[2]=0
	score[3]=0

	local bg = {}
	bg[1] = display.newImage("image/UI/main title/title_bg.png")
	bg[1].x, bg[1].y = display.contentWidth/2, display.contentHeight/2
	
	local pipeGroupe = display.newGroup()
	local pipe = {}

	pipe[1] = display.newImage(pipeGroupe, "image/bedroom/pipe_1.png")
	pipe[1].x, pipe[1].y = display.contentWidth/2-250, display.contentHeight/2

	pipe[2] = display.newImage(pipeGroupe, "image/bedroom/pipe_2.png")
	pipe[2].x, pipe[2].y = display.contentWidth/2, display.contentHeight/2

	pipe[3] = display.newImage(pipeGroupe, "image/bedroom/pipe_3.png")
	pipe[3].x, pipe[3].y = display.contentWidth/2+270, display.contentHeight/2

	local flag = display.newText("실패", display.contentWidth * 0.1, display.contentHeight * 0.15)
	flag.size = 100
	flag:setFillColor(0)

	local function tapPipe(event)
		if(pipe[1].x-50 < event.target.x and event.target.x < pipe[1].x+50
			and pipe[1].y-50 <event.target.y and event.target.y < pipe[1].y+50) then
			pipe[1]:rotate(90)
			score[1] = score[1] + 1
		elseif(pipe[2].x-50 < event.target.x and event.target.x < pipe[2].x+50
			and pipe[2].y-50 < event.target.y and event.target.y < pipe[2].y+50) then
			pipe[2]:rotate(90)
			score[2] = score[2] + 1
		elseif(pipe[3].x-50 < event.target.x and event.target.x < pipe[3].x+50
			and pipe[3].y-50 < event.target.y and event.target.y < pipe[3].y+50) then
			pipe[3]:rotate(90)
			score[3] = score[3] + 1
		end
	end

	local function judge()
		if(score[1] % 4 == 0 and score[2] % 4 == 1 and score[3] % 4 == 1) then
			flag.text = "성공!"
		else
			flag.text = "실패!"
		end
	end

	local total = 0
	for i=1,3 do
		pipe[i]:addEventListener("tap", tapPipe)
		pipe[i]:addEventListener("tap", judge)
	end

end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
